<?php 

$redirect_uri = '';

$options = array();
$options['state'] = '';
$options['username'] = '';
$options['email'] = '';
?>

<div>
	
	Your account was created.
</div>
