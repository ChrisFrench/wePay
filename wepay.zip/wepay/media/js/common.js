if (typeof(Wepay) === 'undefined') {
    var Wepay = {};
}