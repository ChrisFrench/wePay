<?php defined('_JEXEC') or die('Restricted access'); ?>
<?php include JPATH_SITE . '/libraries/dioscouri/component/view/element/default.php'; ?>